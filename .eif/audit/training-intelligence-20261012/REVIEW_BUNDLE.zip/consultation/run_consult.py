"""One tool-disabled external consultation explicitly requested by the operator."""
from pathlib import Path
import os
import subprocess
import json
from datetime import datetime, timezone

folder = Path(__file__).resolve().parent
exe = Path(os.environ['APPDATA'])/'npm/node_modules/@anthropic-ai/claude-code/bin/claude.exe'
args = [str(exe), '--print', '--model', 'opus', '--safe-mode', '--tools', '', '--strict-mcp-config', '--no-session-persistence', '--output-format', 'json']
started = datetime.now(timezone.utc).isoformat()
with (folder/'request.txt').open('rb') as inp, (folder/'response.json').open('wb') as out, (folder/'stderr.txt').open('wb') as err:
    try:
        result = subprocess.run(args, stdin=inp, stdout=out, stderr=err, timeout=480, cwd=folder)
        code = result.returncode
    except subprocess.TimeoutExpired:
        code = 'TIMEOUT'
(folder/'receipt.json').write_text(json.dumps({'started_utc':started,'ended_utc':datetime.now(timezone.utc).isoformat(),'requested_model':'opus','tool_access':False,'session_persistence':False,'exit_code':code,'scope':'Supplied packet only; no independent repository/device access'},indent=2),encoding='utf-8')
print('Consult exit:', code)
