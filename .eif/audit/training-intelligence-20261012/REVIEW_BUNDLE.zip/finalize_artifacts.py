"""Verify and package audit artifacts without changing product or programme state."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile
from datetime import datetime, timezone

audit = Path(__file__).resolve().parent
root = audit.parents[2]
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root).decode().strip()

diff = subprocess.check_output(['git','diff','--binary'],cwd=root)
diff_hash = subprocess.check_output(['powershell','-NoProfile','-Command','git diff --binary | git hash-object --stdin'],cwd=root).decode().strip()
report = audit/'PROJECT_AUDIT_REPORT.md'
missing = []
for doc in [report,audit/'README.md']:
    for link in re.findall(r'\]\(([^)]+)\)',doc.read_text(encoding='utf-8')):
        if '://' in link or link.startswith('#'):
            continue
        if link == 'evidence/final-verification.json':
            continue  # This command produces this receipt below.
        if not (doc.parent/link.split('#')[0]).exists():
            missing.append({'document':doc.name,'link':link})
packet = '\n\n'.join((audit/name).read_text(encoding='utf-8-sig') for name in ['PROJECT_AUDIT_REPORT.md','training/REPORT.md','product/HANDOFF.md','framework/REPORT.md','product/verification-deltas.md','framework/final-review.md','consultation/ADJUDICATION.md'])
(audit/'REVIEW_PACKET.md').write_text(packet,encoding='utf-8')
manifest = {}
for p in sorted(audit.rglob('*')):
    if p.is_file() and p.suffix != '.zip' and p.name != 'final-verification.json' and '__pycache__' not in p.parts:
        manifest[p.relative_to(audit).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
record = {'observed_utc':datetime.now(timezone.utc).isoformat(),'branch':git('branch','--show-current'),'head':git('rev-parse','HEAD'),'tracked_diff_git_blob_hash':diff_hash,'initial_tracked_diff_git_blob_hash':'016d8efa3492816006334859aef8b27911d3b2d6','tracked_diff_preserved':diff_hash=='016d8efa3492816006334859aef8b27911d3b2d6','missing_report_links':missing,'artifact_sha256':manifest,'scope':'audit only; no full-suite, current Android or live DB verification'}
(audit/'evidence/final-verification.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
assert record['tracked_diff_preserved'] and not missing
assert record['head']=='a9163835e7e649c101320853d85fd8df1e5b883e'
assert record['branch']=='fix/training-confident-ux'
with zipfile.ZipFile(audit/'REVIEW_BUNDLE.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(audit.rglob('*')):
        if p.is_file() and p.suffix != '.zip' and '__pycache__' not in p.parts:
            z.write(p,p.relative_to(audit).as_posix())
print(json.dumps({'files_hashed':len(manifest),'missing_links':missing,'tracked_work_preserved':record['tracked_diff_preserved'],'report_chars':len(report.read_text(encoding='utf-8')),'packet_chars':len(packet),'bundle_bytes':(audit/'REVIEW_BUNDLE.zip').stat().st_size}))
