"""Read-only audit of recorded EIF events and pinned upstream pure functions.

Never imports or reads the installed .eif/runtime implementation.
"""
import ast
import collections
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
log = ROOT / '.eif/program/PROGRAM_LOG.ndjson'
events = [json.loads(line) for line in log.read_text(encoding='utf-8').splitlines()]
verifications = [e for e in events if e['event'] == 'node.verification']
source = OUT / 'upstream/tools/eif_program/journeys.py'
parsed = ast.parse(source.read_text(encoding='utf-8'))
names = {'select_journeys', 'required_journey_ids', 'frozen_required_journey_ids', 'journeys_gate_ok'}
module = ast.Module(body=[n for n in parsed.body if isinstance(n, ast.FunctionDef) and n.name in names], type_ignores=[])
scope = {'Any': object, 'QUALITY_DONE': {'pass', 'resolved', 'na'}}
exec(compile(module, str(source), 'exec'), scope)
journeys = [{'id': 'strength', 'nodes': ['N-0020'], 'steps': ['open']}]
node = {'id': 'N-9999', 'class': 'feature', 'verification': {'journeys': {
    'required_ids': ['strength'], 'state': 'na', 'rationale': 'accepted', 'covered_ids': []}}}
result = {
    'framework_sha': 'f03832d7b95f3fc293b02294e5215f1a4b6453ee',
    'scope': 'Pinned upstream pure functions; NOT an installed runtime probe',
    'event_count': len(events),
    'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
    'actors': dict(collections.Counter(e['actor'] for e in events)),
    'event_types': dict(collections.Counter(e['event'] for e in events)),
    'verification_counts': dict(collections.Counter(str((e['payload'].get('kind'), e['payload'].get('state'))) for e in verifications)),
    'independence_fields_present': sum('independence' in e['payload'] for e in verifications),
    'unrelated_node_still_selects_nodes_scoped_journey': bool(scope['select_journeys'](journeys, node_class='feature')),
    'na_without_coverage_passes': scope['journeys_gate_ok'](node, journeys),
    'explicit_empty_required_ids_passes': scope['journeys_gate_ok']({'verification': {'journeys': {'required_ids': [], 'state': 'pending'}}}, journeys),
    'local_evidence_hashes': {},
}
for rel in ['scripts/eif_node.py', '.eif/JOURNEYS.yaml', '.eif/RUNTIME_CAPABILITIES.md', '.cursor/eif-runtime-manifest.json', 'docs/eif/CHARTER.md', 'docs/eif/baseline/N0011_WEEKLY_VOLUME.md', 'docs/eif/baseline/N0023_FOUR_WEEK_PROGRESSION.md', 'docs/eif/baseline/N0024_HARNESS_CI.md']:
    result['local_evidence_hashes'][rel] = hashlib.sha256((ROOT / rel).read_bytes()).hexdigest()
print(json.dumps(result, indent=2))
