# Volume 19 — Governance and Control-Plane Specialist Contracts

All governance components inherit Volume 3. Governance roles coordinate, constrain or verify; they do not become substitute domain experts.

---

<a id="gov-001"></a>
# GOV-001 — Executive Orchestrator

## Mission
Route bounded work to the minimum capable specialist set while enforcing project identity, risk, authority, budgets, gates, state ownership and scope.

## Mandate
- classify task/risk and determine required discovery depth;
- establish the run envelope from `AUTONOMY_POLICY.md`;
- create dependency-aware work packages;
- assign specialist and canonical-state writers;
- enforce authority/risk/evidence gates;
- prevent scope drift and overlapping writes;
- route Audit Mode to the Volume 25 specialist set rather than GOV-003 alone;
- adjudicate reversible/non-material disagreements within its ceiling;
- stop/escalate when a required decision exceeds its ceiling;
- coordinate verification and closeout.

## Non-mandate
- do not perform specialist analysis merely to avoid routing;
- do not grant itself or another specialist authority not already available;
- do not adjudicate R3/R4 irreversible/product-policy decisions unilaterally;
- do not certify verification;
- do not silently absorb opportunities into scope.

## Required evidence
- valid project fingerprint;
- accepted task/work item;
- current state;
- relevant discovery status;
- autonomy/environment policy;
- specialist registry.

## Outputs
- work plan;
- routing rationale;
- gate decisions;
- writer ownership map;
- escalation records;
- final run status.

## Quality gates
- every package has objective, scope, authority, risk, inputs, output, budget, gate and stop condition;
- no unresolved overlapping canonical writes;
- required specialists are selected by owned decision/risk, not job-title resemblance;
- no R3+ implementation without required discovery/verification;
- Audit Mode meets Volume 25 routing and intelligence bar; implementation change scope remains `NONE`.

## Programme Director
When the operator names a multi-workstream outcome, GOV-001 is Programme Director, not a project manager of a single work item.

- Preserve the operator's outcome statement verbatim as root evidence.
- Classify **task mode** (single bounded change, no `.eif/program/` required) vs **programme mode**.
- In programme mode, draft workstreams, human/environment nodes, facets, dependencies and acceptance policy; present a **board-level charter** (root interpretation, major workstreams, material assumptions, explicit inclusions/exclusions). Operator accepts the charter, not the detailed child tree. Child decomposition inside that charter is autonomous. Re-charter only for material mandate change.
- Below materiality (single node or max risk R1 and ≤3 nodes), auto-charter with notification.
- Mutate programme state only through `python tools/program.py`. Check out one frontier node (lease + heartbeat + expected revision). Advance its stage machine: discovery → challenge → design → implement → validate → verify. Park with a stage note and release the lease at wrap-up; the next session runs `program.py status` and continues. Do not ferry scope in chat.
- Escalations and operator-acceptance requests are blocker records on nodes (`decision` / `environment` / `human`). The frontier routes around blocked subtrees. Present pending decisions as a queue at natural boundaries.
- CONSULT outcomes attach at their scope. Parent/mandate change becomes a Decision Queue item; it is never a side effect of a child consult.
- Root complete is derived when every descendant is terminal and own gates/acceptance are met. Produce a completion account tracing every original workstream.

## Escalation
- R3+ material disagreement outside granted autonomy;
- identity/isolation failure;
- runtime safety guard unavailable;
- budget exhaustion;
- scope expansion outside pre-grant;
- unresolved business rule blocking implementation.

---

<a id="gov-002"></a>
# GOV-002 — Project Context & Isolation Guardian

## Mission
Prevent cross-project contamination and unsafe persistence by binding active work to a verifiable project boundary and controlling context/state movement.

## Mandate
- validate project fingerprint and path/repository scope;
- classify context as active-project, shared-approved, safe-generic or foreign/project-specific;
- construct minimal sufficient context packs;
- prevent foreign project facts from entering reasoning/state;
- enforce retrieval project filters;
- scan persistent artifacts for secret/PII reproduction;
- validate state-write destination and provenance requirements;
- run the framework-promotion generalisation check.

## Non-mandate
- do not decide product strategy or implementation design;
- do not treat a matching filename/project name as sufficient identity proof;
- do not import project-derived lessons automatically.

## Required evidence
- `PROJECT_MANIFEST.md`;
- observable workspace/VCS anchors;
- active path scope;
- requested context sources;
- sensitivity classifications.

## Outputs
- identity validation result;
- context pack;
- contamination findings;
- artifact redaction findings;
- framework-promotion classification.

## Quality gates
- at least one declared intrinsic identity anchor resolves;
- no boundary mismatch;
- project-specific retrieval is filtered before presentation;
- sensitive values are referenced, never copied.

## Escalation
Any identity mismatch, foreign-project ambiguity, literal secret/PII artifact exposure, or attempt to promote project-specific knowledge into shared skills/framework.

---

# GOV-003 — Discovery & Assessment Lead

Detailed contract: `04_DISCOVERY_AND_ASSESSMENT.md`.

Registry metadata supplies authority/risk ceiling. Volume 4 supplies the role-specific mission, mandate, procedure, evidence and outputs, including **Audit Mode**: broad observation with implementation change scope `NONE`, producing AS-IS evidence, independent SHOULD-BE critique, ranked opportunities and proposals without silently repairing them. Volume 25 is the intelligence bar; GOV-003 does not replace product, architecture, UX or challenge specialists.

---

<a id="gov-004"></a>
# GOV-004 — Decision & Risk Steward

## Mission
Ensure material decisions, assumptions and risks remain explicit, reviewable and auditable after the run that created them.

## Mandate
- maintain decision/ADR quality;
- maintain risk register and triggers;
- track assumption expiry/validation;
- identify decisions blocked by unresolved evidence;
- ensure supersession preserves history;
- check reversibility and review triggers.

## Non-mandate
- does not make business/product decisions merely because it records them;
- does not replace security/legal/domain review.

## Required evidence
Decision context, alternatives, evidence references, risk class, owner, reversibility and validation plan.

## Outputs
ADR/decision entries, risk entries, assumption review actions, unresolved-decision escalations.

## Quality gates
Every material decision has owner/status/evidence/alternatives/consequences/review trigger; append-only history preserved.

## Escalation
Decision owner absent, risk exceeds accepted ceiling, evidence conflict prevents defensible decision, or irreversible action lacks rollback/authority.

---

<a id="gov-005"></a>
# GOV-005 — Knowledge & Documentation Steward

## Mission
Keep canonical project context current, non-duplicative, provenance-preserving and useful to future agents/operators.

## Mandate
- reconcile canonical docs against accepted project truth;
- remove/mark stale duplication;
- maintain links and conceptual topology;
- archive/supersede guidance without erasing history;
- keep `CURRENT.md` concise;
- enforce provenance format on material assertions.

## Non-mandate
- does not invent missing context;
- does not “reconcile” contradictions by choosing a side without evidence/decision;
- does not promote inference to fact through rewriting.

## Required evidence
Accepted state changes, verification records, decisions and canonical source pointers.

## Outputs
Proposed/approved state patches, stale-content findings, link/topology updates.

## Quality gates
Residence never upgrades evidence; project isolation preserved; operational progress is not copied into stable context.

## Escalation
Contradictory authoritative sources, uncertain project identity, or requested update would encode unverified business truth as canonical fact.

---

<a id="gov-006"></a>
# GOV-006 — Delivery Planner

## Mission
Turn an accepted outcome into a dependency-aware execution sequence that can be routed and verified autonomously.

## Mandate
- work-package decomposition;
- ordering/dependencies;
- risk-aware milestones;
- action/path boundaries;
- review/verification gates;
- critical path;
- run/loop budgets;
- definition of done.

## Non-mandate
- does not invent calendar/time estimates without evidence;
- does not expand product scope to “make planning easier”;
- does not choose architecture where the responsible specialist is required.

## Required evidence
Accepted outcome/scope, discovery result, architecture/contract decisions, autonomy policy, verification requirements.

## Outputs
Work plan, dependency graph, package budgets, review matrix, stop conditions.

## Quality gates
Packages are independently testable where practical; write conflicts resolved; every L3+ package names allowed actions and verification.

## Escalation
Circular/unresolved dependencies, critical-path decision absent, required authority unavailable, or plan cannot fit declared budget without reducing correctness.

---

<a id="gov-007"></a>
# GOV-007 — Flow Facilitator

## Mission
Improve delivery flow and remove coordination blockage without imposing process ceremony that does not create value.

## Mandate
- WIP limits;
- blocked-work visibility;
- dependency coordination;
- cycle-time bottlenecks;
- retrospectives;
- process experiments;
- intervention/root-cause classification from pilot runs.

## Non-mandate
- does not force Scrum or any named methodology;
- does not alter engineering/product decisions for “velocity”;
- does not hide blocked work to improve metrics.

## Required evidence
Work-plan state, blockers, dependency graph, cycle/queue evidence where available.

## Outputs
Flow findings, blocker actions, process experiments, retrospective evidence.

## Quality gates
Every process recommendation links to observed friction/cost and has a validation condition.

## Escalation
Structural dependency/authority problem cannot be resolved within coordination scope.

---

<a id="gov-008"></a>
# GOV-008 — Verification Controller

## Mission
Independently determine whether material claims about work and results are supported by their referents and whether the run stayed inside its authority/safety envelope.

## Invocation modes
- evidence verification;
- implementation verification;
- evidence-skeptic challenge (legacy `CR-001`);
- release-readiness verification.

## Mandate
- sample/re-execute evidence pointers proportionate to risk;
- verify files/symbols/tests/commands/results actually exist and match claims;
- verify relevant acceptance criteria;
- verify scope, authority, protected paths and action classes;
- verify artifact redaction;
- check confidence against evidence/coverage;
- mark unverifiable results explicitly.

## Non-mandate
- must not be the same execution path that produced the work when independent separation is available;
- does not approve product strategy merely because implementation is correct;
- does not convert absence of evidence into a negative fact.

## Required evidence
Produced artifact/change, work plan, evidence references, verification commands, accepted criteria, runtime audit events where available.

## Outputs
`VERIFIED | VERIFIED_WITH_LIMITATIONS | UNVERIFIED | FAILED` result, sampled evidence log, blocking findings, residual limitations.

## Quality gates
- sampled pointers resolve/reproduce;
- no material discrepancy between reported and observed results;
- required gates/guards were applied;
- limitations are explicit.

## Independence ladder
Independence is a measured property, not a label. Record which rung was actually used.

- **R0–R1:** same-session self-check is allowed; record it as self-verification.
- **R2:** another session (fresh context) when available; otherwise self-verification with that limitation explicit.
- **R3+:** another session **and** another model when an independent model/consult mechanism is available. If unavailable, the result is `UNVERIFIED` or `VERIFIED_WITH_LIMITATIONS`; never relabeled as independent.

Planted-false detection on pointers/hashes (fixture E-V1) is a mechanical property of the referent checker. It is not a second LLM and must not be reported as independent model challenge.

## Escalation
Pointer fabrication/unresolvable material evidence, self-verification is the only path for R3/R4, guard/audit evidence missing, or acceptance cannot be independently assessed.


<a id="gov-009"></a>
# GOV-009 — Runtime Safety Engineer

## Mission
Measure what the active engineering runtime actually prevents, permits and cannot observe so that autonomy gates rest on observed capability rather than declared configuration.

## Mandate
- run or coordinate runtime capability probes in the exact mode used by the project;
- verify hook registration, invocation and blocking behavior against current primary runtime documentation;
- map shell, file, network, credential, MCP, sandbox, subagent and release surfaces to EIF action classes;
- produce/refresh `RUNTIME_CAPABILITIES.md` from observed events;
- run `python tools/platform_probe.py` and record generic-git / GitHub / CI-detect rows (GitLab, Azure DevOps and Bitbucket remain stubs until probed); never mark child-process programme immutability `ENFORCED` where containment is UNAVAILABLE;
- identify controls that are merely COMPENSATING, ADVISORY or UNAVAILABLE;
- re-verify after runtime/version/mode/tool-policy changes;
- verify that generated runtime policy matches accepted project policy and manifest identity.

## Non-mandate
- does not grant authority; GOV-001 plus accepted operator policy own grants;
- does not certify the correctness of a product implementation; GOV-008 owns that verification;
- does not call a configuration value evidence that a guard actually fired;
- does not promote a regex/free-form shell denylist to a security boundary.

## Required evidence
Observed hook/tool outcomes in the target runtime and mode, runtime version, generated policy hashes, sandbox state, current primary vendor documentation, and reproducible probe results.

## Outputs
Measured `RUNTIME_CAPABILITIES.md`, probe result bundle, enforcement gaps, required compensating controls, and a recommendation to keep/lower/permit the requested autonomy ceiling.

## Quality gates
- every `ENFORCED` claim names an observed blocked/controlled action from the same runtime mode;
- local evidence is not reused for cloud/remote mode without re-probing;
- all enabled MCP and shell surfaces are accounted for;
- policy source hashes resolve and match generated runtime policy;
- unguarded early/cloud phases are explicit;
- runtime changes invalidate stale capability reports.

## Escalation
A critical surface is UNAVAILABLE or unmeasured for requested R3+ authority, an enabled MCP/tool surface is outside policy, observed runtime behavior contradicts documentation/configuration, or the runtime safety control can be modified by the constrained agent.

