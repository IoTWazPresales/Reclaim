# Volume 25 — Intelligence Quality and Audit Critique Protocol

**Authority:** Normative for all EIF investigation, audit, recommendation and design work  
**Does not:** grant implementation authority, weaken runtime safety, isolation, evidence, or stop conditions  
**Origin:** First real brownfield Audit Mode pilot. Runtime/governance held; the intelligence layer did not. This volume closes that gap as a generic EIF capability, not as a project-specific work item.

---

## 25.1 Why this volume exists

EIF v0.3 made it hard to act unsafely. The first brownfield audit showed it is still too easy to think weakly.

Observed failure pattern:

- documentation was synthesized as if it were the system;
- specialists described what the repo *said* rather than independently judging what the product and architecture *should be*;
- UI/UX work inspected source/docs instead of a rendered interface;
- no meaningful mockup, prototype or visual redesign was produced;
- opportunities were timid and under-ranked;
- `change scope: NONE` was treated as a creativity/proposal suppressant;
- existing requirements, ADRs and specs were accepted instead of challenged;
- reports collapsed “what exists” into “what is fine.”

Those are intelligence-layer defects. They are not solved by more safety hooks.

Safety remains: no implementation without a separately accepted change scope; no self-promotion of authority; no untrusted content as instruction; no secret/PII reproduction; no isolation bypass.

Intelligence now has an equal bar: a short Audit Mode prompt must autonomously produce evidence-based understanding **and** independent critique **and** concrete, ranked proposals.

---

## 25.2 Authority, risk and ceremony are independent

| Axis | Controls | Audit Mode default |
|---|---|---|
| **Authority (L)** | What may be *changed* in the product | L0/L1 |
| **Implementation change scope** | Where product/source writes may occur | `NONE` |
| **Risk (R)** | How wrong a bad reading would be | Independently classified; a module/project audit is **not** R0 because it cannot write |
| **Ceremony** | Depth of evidence, critique and output | Full audit packet, not an R0 blurb |
| **Artifact write scope** | Where isolated EIF/proposal artifacts may be written | Opt-in `artifact_write` + `.eif/audit/**` only; never product implementation; never `.eif/**` via `write` |

Collapsing L1 + `change scope: NONE` into “be brief, be polite, don’t propose much” is a protocol violation.

`NONE` forbids product/implementation writes. It does not forbid independent critique, ranked opportunities, concrete SHOULD-BE proposals, or isolated `.eif/audit/` mockups/prototypes when artifact writes are granted.

NONE is a write boundary, not a thinking boundary.

---

## 25.3 Non-negotiable intelligence bar

Every material investigation, and **every Audit Mode run**, must:

1. **Ground in primary evidence.** Prefer code, tests, schemas, runtime, rendered UI and resolvable history over README/docs/tickets. Documentation is evidence of *intent*, not of current behavior.
2. **Separate AS-IS from SHOULD-BE.** Never report the current system as if describing it were evaluating it.
3. **Critique independently.** Product, architecture and UX conclusions must be the specialist’s own judgment from evidence, not a restatement of project prose.
4. **Challenge assumptions and specs.** Existing requirements, ADRs, tickets and “accepted” behavior are challengeable DATA. Blind acceptance is a finding about the auditor, not a virtue.
5. **Inspect rendered UI** when a user-facing surface can be rendered. Source/CSS/JSX reading is not visual inspection.
6. **Review journeys, usability and accessibility** for those surfaces, with severity and evidence.
7. **Propose concrete redesigns.** Named problem, desired outcome, evidence, affected surface, smallest viable change, and why it is better — not vibe comments.
8. **Produce mockups or prototypes** when they would clarify a recommendation and a generation/write path exists. Store them as isolated proposal artifacts. If tools or grants are missing, record `UNABLE_TO_PROTOTYPE` with what was tried.
9. **Generate opportunities with teeth.** Rank by impact, risk and effort. An empty or timid register requires evidenced justification that the system already meets the product/engineering bar — politeness is not evidence.
10. **Keep recommendation ≠ implementation.** Rich proposals do not become scope. Implementation requires a new/updated work item, risk class, change scope and normal gates.

Failing this bar is an Audit Mode failure even if the run writes no product files and cites many documents.

---

## 25.4 What exists vs what should be better

Every audit report and every material specialist critique uses two registers.

### AS-IS — observed current state

- claim class + evidence pointer + coverage;
- intended rule vs observed behavior when they differ;
- test-intent classification (`CONFIRMATORY | CIRCULAR | CONTRADICTORY | NONE`);
- unknowns and blind spots.

AS-IS may not include value judgments disguised as description (“the UI is clean”, “the architecture is modular”) unless those adjectives are evidenced.

### SHOULD-BE — independent recommended state

- labeled `PROPOSAL` or `HYPOTHESIS`;
- problem/outcome;
- why the current state is insufficient;
- better alternative(s), including the case for *keeping* the current design when it is actually strong;
- impact / risk / effort;
- required future authority and change scope to implement;
- reversibility and cheapest validation.

SHOULD-BE must not be a paraphrase of AS-IS. If the auditor has no critique, they must say what was evaluated and why the current design survives challenge.

---

## 25.5 Documentation is not the system

Normative evidence order for **current behavior**:

1. executable/runtime observation (E0);
2. source, schema, tests, configuration (E0/E1 for implementation facts);
3. version-control history for churn/intent (usually E4 for prose, E0/E1 for the fact of a revert/fix);
4. documentation, README, tickets, specs, ADRs (intent / claimed design — not current behavior unless independently confirmed).

Rules:

- A fluent README is not a system map.
- Copying headings from docs into an audit report is synthesis, not discovery.
- When docs and code disagree, record the contradiction; do not silently prefer docs.
- Specs/ADRs constrain *intent*. They do not forbid a PROPOSAL that the spec is wrong, stale, harmful, under-specified, or solving the wrong problem.
- “The docs say X” is never sufficient as a product or architecture conclusion.

Discovery Pass 1 (documentary sources) produces an **intent register**. Pass 2+ (executable/source/UI) produces the **current-state register**. Reconciliation is explicit.

---

## 25.6 Independent product and architecture critique

Audit Mode is not a documentation harvest. After the evidence baseline exists, specialists must answer:

### Product (PB-001 and/or PB-002, plus CR-007)

- Is this the right problem for the stated user/job?
- Which requirements are load-bearing vs accidental vs harmful?
- What would a sharp product owner cut, change, or refuse?
- Where is the workflow slower, more confusing, or less valuable than the job requires?
- What opportunity is being left on the table that the current roadmap/spec does not name?

### Architecture (AE-002 at the altitude of the audited surface)

- Are boundaries, ownership, contracts and failure domains coherent?
- What coupling, duplication, or missing seam will punish change?
- Is the current shape the simplest that satisfies the real quality attributes — or historical accretion?
- What should be reused, extracted, replaced, or explicitly kept?
- What would you refuse to build on top of without first changing?

Critique is evidence-bound. It is not mandatory disagreement with everything. It *is* mandatory independent judgment. Restating module names from a README is not critique.

GOV-003 owns coverage and the audit bundle. It does **not** substitute for product, architecture, UX or challenge specialists.

---

## 25.7 Challenge of existing requirements and specs

Specialists must treat current requirements as hypotheses about the right product.

For each material requirement, ADR, ticket or “accepted behavior” that shapes the audited surface:

```md
Requirement/spec:
Source:
Observed support in current system:
User/job it claims to serve:
Challenge:
  keep | reframe | replace | delete | unknown
Evidence for the challenge:
Risk of keeping it unchanged:
Proposed better rule (PROPOSAL):
```

“No challenges” is allowed only when named requirements were actually tested against user/job, code, and failure modes, and survived. Skipping the exercise is a fail.

This does not authorize implementing a different spec. It produces PROPOSALs for a later accepted work item.

---

## 25.8 Visual inspection protocol

Reading component source, CSS, Storybook code, or a design-system document is **not** visual inspection.

### Detect a renderable UI

A user-facing surface is renderable when any of these exist: web/app routes, HTML/CSS/JS UI, native screens, Storybook/preview, a running local/dev/staging URL in project config, or checked-in screenshots/recordings of the current product.

If none exist (library/API-only, headless worker), record `NO_RENDERABLE_UI` and skip visual/mockup duties. Journey review then applies only to operator/CLI/API ergonomics if those are the interface.

### Inspect, in this order, using available granted tools

1. Running application or preview: navigate to the local URL, then **use** it as a user would (tabs, drawers, filters, forms, hamburger navigation, row opening, dialogs) and capture snapshot / accessibility tree / screenshot of the resulting states.
2. Locally served UI / Storybook / static HTML actually opened, interacted with, and captured.
3. Current-product screenshots/recordings already in the repo, labeled as secondary if they may be stale.
4. If all of the above are blocked, record `UNABLE_TO_RENDER` with: methods tried, grant/tool missing (for example `mcp.browser` not `interact`, MCP/browser denied, shell/server not available, no URL), and that subsequent UX claims are **source-inferred, not visually observed**.

Never claim “UI reviewed” or “visual design assessed” from step 4. Snapshot of the landing page alone is not journey inspection when the product’s jobs live behind tabs, rows, or responsive navigation.

### Minimum visual record when inspection succeeds

- surfaces/pages/states viewed, including states reached only by interaction;
- viewport/input mode;
- method (browser snapshot / screenshot / a11y tree / in-page interaction);
- notable hierarchy, density, contrast, alignment, and state-coverage defects;
- evidence pointers (screenshot path, snapshot excerpt, URL).

---

## 25.9 Journey, usability and accessibility

When a UI exists, Audit Mode includes:

- **Journey:** critical user jobs, entry points, steps, dead-ends, recovery.
- **Usability:** hierarchy, defaults, feedback, error prevention, cognitive load, speed to first success.
- **Accessibility:** semantic structure, keyboard, focus, names/labels, contrast, target size, motion, errors, zoom/reflow — with blocker/serious/moderate/enhancement severity.

UX-001, UX-002, UX-003 and UX-005 are the default owners. Source-only heuristic review is a fallback under `UNABLE_TO_RENDER`, and must be labeled as such.

### Simulated journey evaluation

When `JOURNEYS.yaml` (or equivalent) declares realistic interaction sequences, walk them on the **rendered** product where possible. Optional schema fields may include: user/job intent; preconditions; criticality; viewport/input mode; observable success criteria; key information the user must understand; recovery/error conditions.

Journey evidence may assess: completion; discoverability; comprehension; efficiency; information sufficiency; decision confidence; error/recovery; accessibility concerns; trust/contradiction between surfaces.

Label this evidence clearly as **simulated product evaluation**, not real-user research or production analytics. Do not invent personas, demographic theatre, or scheduled autonomous persona suites — standing persona verification remains deferred per Programme Release.

A simulated journey must correspond to a real interaction sequence on the real rendered product. Build/tests passing does not substitute for journey discoverability or comprehension failures — record those failures as visible evidence.

---

## 25.10 Redesign recommendations and isolated prototypes

A redesign recommendation is a SHOULD-BE packet, not a suggestion to “consider improving the UI.”

Minimum fields:

- problem and user/job outcome;
- AS-IS evidence (visual if UI);
- proposed interaction/visual change;
- why it is better for this product (not “looks more premium” alone);
- impact / risk / effort;
- reversibility;
- implementation authority that would be required later.

### Isolated proposal artifacts

When a mockup, wireframe, HTML/CSS prototype, flow diagram or generated image would make the recommendation inspectable, produce it.

Store under:

```text
.eif/audit/<audit_id>/
  README.md                 # index of proposal artifacts
  mockups/                  # images, boards
  prototypes/               # isolated HTML/CSS/JS; not product source
  notes.md                  # how to view; what is out of date
```

Rules:

- These files are **recommendations**, not product implementation.
- They must not be copied onto product paths in the same run.
- They do not satisfy “change scope NONE” by living in `src/` with a comment saying “prototype.”
- L1 Recommend includes these isolated artifacts only when `artifact_write` is granted for `.eif/audit/**`. Default L1 is read-only; missing grant → `UNABLE_TO_PROTOTYPE`, not product writes.
- L2 Prepare remains the path for isolated product-like branches that could later be applied.
- L3 is applying an accepted change to implementation change scope.

If image generation, HTML write, or `.eif` write is unavailable, record `UNABLE_TO_PROTOTYPE` rather than claiming a mockup exists.

### Artifact class of isolated prototypes

Declare the artifact class on the owning node (`target_artifact_class:` in acceptance criteria) and on the prototype index. Classes are ordered: `ia_concept` < `interaction` < `high_fidelity`.

- An IA-class prototype may be rooms, objects, navigation, and capability homes. It is a valid completion of an `ia_concept` node. It does not satisfy a `high_fidelity` target.
- An interaction prototype must show task flow, states, and context-preserving behaviour; it is not finished visual identity.
- A high-fidelity prototype is product-facing execution: hierarchy, density, identity, states, work surfaces, and visualisation where causally appropriate. It speaks as the product. Redesign meta-commentary belongs in `notes.md` / the design record, not on the surface.

Do not infer class from filenames or free-text “high-fidelity” claims. The structured field is the target.

---

## 25.11 Opportunity generation bar

Opportunities are not committed scope. They also must not be a timid afterthought.

Each material opportunity:

| Field | Requirement |
|---|---|
| Type | Repair, Simplify, Complete, Differentiate, Defend, Monetize, Automate, Explain, Platform, Experiment, Redesign |
| Evidence | resolvable pointer; not “docs imply” |
| Impact | High / Medium / Low — user/business outcome if done |
| Risk of *not* doing it | High / Medium / Low |
| Effort | High / Medium / Low — honest, qualitative |
| Priority | ranked; impact and unmet-risk outweigh low effort-of-writing |
| Spec challenge | whether this contradicts a current requirement/ADR |
| Validation | cheapest test that would confirm value |
| Implementation authority | L/R and change scope that would be needed later |
| Status | recorded, not accepted |

Ranking is by **impact and risk-of-inaction first**, then effort. Do not bury a high-impact architectural or UX correction because it is larger than a docstring.

An audit that only recommends more documentation, more comments, or “consider adding tests” has failed this bar unless those are truly the highest-impact gaps *and* product/architecture/UX were actually challenged.

---

## 25.12 Audit Mode routing

A normal short operator prompt such as “audit this project/module” is sufficient. The orchestrator must not wait for the operator to name specialists.

### Mandatory control

- **GOV-001** classifies Audit Mode, sets L0/L1, implementation change scope `NONE`, artifact write scope, and independent risk class.
- **GOV-002** identity/isolation as usual.
- **GOV-003** evidence baseline, coverage, contradiction register, audit bundle ownership.
- **GOV-008** samples material evidence pointers; does not tone-police proposals.

### Mandatory critique set for a product/module audit

Minimum:

- product: **PB-002** (and **PB-001** when direction/portfolio is in scope);
- architecture: **AE-002** at the relevant `scope`;
- challenge: **CR-007**, plus **CR-002** when complexity/accretion is visible.

### When a renderable UI exists, also mandatory

- **UX-001** journey/usability;
- **UX-002** interaction/states if flows are material;
- **UX-003** visual inspection and redesign direction;
- **UX-005** accessibility.

Add security, data, reliability, QA, market/premium-benchmark specialists when those surfaces are material. Do not invoke the entire catalogue.

### Forbidden routing failures

- GOV-003 alone;
- “docs-only” pass with no executable/UI evidence;
- skipping UX because change scope is `NONE`;
- skipping CR-007 because a spec already exists;
- treating L1 as permission to omit SHOULD-BE.

Audit Mode never silently transitions to implementation. A later implementation grant is a new envelope.

---

## 25.13 Isolated artifact writes vs implementation writes

`NONE` forbids product/implementation writes.

It does not mean:

- no `PROJECT_AUDIT_REPORT.md` (durable copy lives under `.eif/audit/<id>/`);
- no discovery/opportunity/risk/handoff *proposals*;
- no `.eif/audit/<id>/` mockups or prototypes;
- no ranked proposals.

Durable files require the opt-in artifact grant. Without it, those outputs stay in-chat / `UNABLE_TO_PROTOTYPE`. Canonical `.eif` state files are not an audit dump target.

Recommended Audit Mode autonomy envelope:

- `max_authority: L1`
- `observation_paths` broad enough for evidence
- `write: false` and `change_paths: []` — implementation write stays **NONE**
- opt-in `artifact_write: true` with `artifact_paths: ['.eif/audit/**']` when durable mockups/reports are wanted
- do **not** use `write: true` + `.eif/**`
- canonical `.eif` state/memory/control files remain unwritable
- code-write into application/source trees **not** granted
- MCP/browser: default none. For rendered-UI audits set `mcp.browser: interact` and `network.classes: [loopback]`. That is local-app use, not implementation write and not `public_read` mutation.
- shell/control-plane remain the project default (normally deny/false)
- do **not** grant `public_read` on an L1 audit merely to make browser tools work; research navigate is a separate L3-shaped grant
- `improvement_items: 0`

This is not an L3 grant. Artifact writes do not become implementation scope. Runtime path/action-class guards still apply. F32/F33 exist to keep this split mechanical.

If the operator wants a strictly L0 chat-only audit, that is allowed — the intelligence bar still applies to the chat artifact; only durable files are omitted.

---

## 25.14 Design experience intelligence (material UI/product work)

Raise the product-design ceiling without a new house style, decorative mandate, or specialist proliferation. Extend existing owners: **UX-003** (art direction, divergence, signatures, rendered competition), **UX-002** (SHOULD-BE product architecture), **CR-006** (anti-sameness + cross-category principle transfer), **UX-001** (simulated journeys), **Volume 17** (benchmark/innovation).

### Activation — proportional ceremony

Attach the **`design_experience`** programme facet (see `program/facet_map.yaml`) only for material work:

| Activate | Do not activate |
|---|---|
| new product shell | button colour adjustment |
| substantial redesign | small CSS defect |
| major information-architecture change | copy typo |
| significant new user-facing capability | minor form alignment |
| explicit art-direction request | ordinary bug fix |
| high-impact product experience | narrow accessibility correction |

Nodes with only the `ui` facet keep existing cheap quality checks (ux, a11y, rendered, content). The `design_experience` facet adds process/evidence dimensions — blocked at completion until satisfied or explicitly `na` with class-correct rationale. Aesthetic quality is **not** scored by these gates; rendered/model review handles design quality.

Required on every `design_experience` node:

- `design_artifact_class` (cannot be `na`)
- `design_divergence`
- `design_signatures`
- `rendered_comparison`
- `design_sameness_review`

Class-skippable (may be `na` on a lower class only with rationale containing `artifact_class=<delivered_class>`):

- `design_interaction_spec`
- `design_state_coverage`
- `design_identity_tokens`
- `design_execution_decisions` — structured slots `responsive_decision`, `visualisation_decision`, `consequential_action_decision`, each `applicable` or `not_applicable` with rationale. Dummy blanket `na` cannot satisfy `high_fidelity`.

Audit Mode: when material visual/product redesign is in scope, route **UX-003** with art-direction ceremony, **UX-002** for SHOULD-BE architecture, and **CR-006** for anti-sameness and cross-category benchmarking. CR-006 is strongly preferred over inventing a new challenger specialist.

### Per-node artifact class

Target class is declared only as a structured acceptance-criterion line `target_artifact_class: ia_concept|interaction|high_fidelity`. Delivered class is `design_artifact_class` on the node. Delivered rank must meet or exceed target (`ia_concept` < `interaction` < `high_fidelity`).

A programme may sequence the three classes as separate nodes. Missing target fails the quality gate the same way as a missing delivered class. Fidelity is never inferred from free-text keywords.

`ia_concept` may complete without a design-record file and must not `pass` high-fidelity-only kinds. `high_fidelity` cannot satisfy design requirements through blanket `na`.

For high-fidelity work, generic evidence should cover where applicable (see Volume 10 UX-002 / UX-003 / UX-007): domain-representative density; multi-channel hierarchy; domain-appropriate work surfaces; context-preserving interaction; states beyond rest; consequential-action trust; data/intelligence visualisation where causally appropriate; declared identity tokens; domain-appropriate type/numeric treatment; explicit responsive decision; visual-vocabulary anti-sameness even when IA already differs; product-facing prototype voice.

Do **not** turn those into host-shaped rules: no mandated grid library, master-detail, charts, palettes, typefaces, layouts, row/column counts, or universal density thresholds.

### Divergence, signatures, rendered competition

See UX-003 contract (Volume 10). Major shell/new product/substantial redesign: ≥3 genuinely different directions unless evidenced preservation of mature design DNA. Material module redesign: ≥2. Trivial UI: none.

Design signatures (~2–4 when appropriate) are functional product-specific principles, not slogans.

Rendered competition: diverge first, shortlist, render ≥2 materially different major candidates when practical, inspect/interact, compare with comparative judgments (not fake scores), record winner/rejects. Operational excellence remains non-negotiable.

### Records

Use `.eif/audit/<id>/` with `provenance: design-direction` and optional `design_experience_record` (see `templates/DESIGN_EXPERIENCE_RECORD.md`). These are not implementation baselines. The record file is optional and is not a completion gate for `ia_concept`. High-fidelity work still needs the structured quality evidence kinds even if the file is absent.

---

## 25.15 What this volume does not do

- It does not raise default implementation or artifact-write authority.
- It does not allow observation scope to imply product writes.
- It does not treat `write: true` + `.eif/**` as a valid audit envelope.
- It does not require MCP, browser, or image generation to be default-enabled.
- It does not let a prototype in `.eif/audit/` be merged into product code in the same run.
- It does not replace evidence classes, stop conditions, or GOV-009 measurement.
- It does not claim that always-on rules make model compliance ENFORCED. Intelligence-bar compliance is **ADVISORY** at the model layer and **tested** by F34–F52 transcripts plus human grading. Deterministic class/evidence gates (F38, F47) do not score aesthetic quality.

---

## 25.16 Cursor / runtime honesty

The following cannot be guaranteed merely because this volume exists:

- that Cursor will auto-invoke every named specialist skill from a short prompt (always-on core rule + GOV-001 routing are the compensating instructions);
- that a browser/MCP/screenshot tool is available in the active mode (default MCP deny is intentional; UI audits need an accepted `mcp.browser: interact` plus loopback);
- that image generation is available;
- that a local UI server may be started (L1 shell is deny; L3 workspace may start a local server);
- that GOV-008 is a genuinely separate verifier path (see F31);
- that the model will obey ADVISORY intelligence rules (evals must actually be run).

When a capability is absent, record the coverage limitation. Do not invent visual evidence or mockups.

---

## 25.17 Eval mapping

| ID | Class | Guards |
|---|---|---|
| F32 | deterministic | observation read ≠ implementation write |
| F33 | deterministic | `artifact_write` allows `.eif/audit/**` only; product trees and canonical `.eif` files stay denied; no grant → audit tree denied |
| F34 | model behavior | docs vs code; no documentation regurgitation as system truth |
| F35 | model behavior | `change scope: NONE` does not suppress ranked proposals; no implementation writes |
| F36 | model behavior | existing spec/ADR is challenged rather than blindly accepted |
| F37 | model behavior | renderable UI requires visual inspection attempt, journey/a11y, redesign, mockup or explicit inability |
| F38 | deterministic | `design_experience` facet activates material design dimensions; trivial `ui`-only nodes do not |
| F39 | model behavior | competent-but-generic design: distinctiveness/art direction weakness recognised, not blanket pass |
| F40 | model behavior | three fake alternatives differing only in palette/styling rejected as superficial divergence |
| F41 | model behavior | pretty-but-operationally-worse design loses to operationally stronger candidate |
| F42 | model behavior | novelty theatre challenged when unusual interaction has no user/job advantage |
| F43 | model behavior | mature design DNA preserved; divergence not forced for demonstration |
| F44 | model behavior | cross-category principle transferred with causal reasoning, not surface clone |
| F45 | model behavior | journey/simulated evaluation exposes discoverability failure despite green build tests |
| F46 | model behavior | trivial UI work does not trigger multi-concept art-direction ceremony |
| F47 | deterministic | per-node `target_artifact_class` / delivered class; evidence kinds by class; sequenced IA then HF; trivial UI stays cheap; HF cannot `na`-all |
| F48 | model behavior | structural IA divergence does not satisfy visual-vocabulary anti-sameness |
| F49 | model behavior | high-fidelity work must match domain-representative density, hierarchy, and work surfaces |
| F50 | model behavior | high-fidelity interaction requires states, context preservation, and consequential-action trust |
| F51 | model behavior | visualisation is required when it is the product differentiator; not a universal chart mandate |
| F52 | model behavior | high-fidelity identity tokens, product-facing prototype voice, explicit responsive decision |

F21–F27 and existing safety fixtures remain in force. This volume adds intelligence coverage; it does not replace runtime measurement.

