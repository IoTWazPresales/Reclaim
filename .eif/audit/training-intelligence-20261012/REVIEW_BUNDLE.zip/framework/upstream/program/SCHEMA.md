# EIF Programme schema

**Authority:** `PROGRAM_LOG.ndjson` (append-only).
**Materialization:** `PROGRAM.yaml` (rebuildable snapshot; never a second source of truth).
**Mutation path:** `python tools/program.py` only.
**Views:** `CURRENT.md`, `ROADMAP.md`, `WORK_ITEM.md`, `ESCALATION.md` are GENERATED when `.eif/program/` exists.

This file is the durable schema. It is not always-loaded operator context.

## Paths

```
.eif/program/PROGRAM_LOG.ndjson
.eif/program/PROGRAM.yaml
.eif/program/.lock
.eif/runs/<run>/RUN_LOG.ndjson
```

## Event envelope

Each log line is one JSON object:

```json
{
  "seq": 1,
  "ts": "2026-08-23T16:00:00Z",
  "run": "R20260823T160000Z",
  "actor": "gov-001",
  "event": "programme.init",
  "payload": {}
}
```

`seq` is monotonic from 1. Gaps or duplicate seq fail `verify`.

## Programme header (snapshot)

- `id` — `PRG-…`
- `outcome_statement` — operator verbatim; immutable after init
- `conservation_nouns` — nouns that must remain accounted
- `charter` — `{status, by, at, workstreams, assumptions, inclusions, exclusions, root_interpretation}`
- `status` — `active | suspended | complete`
- `identity` — `{form: pre_history|vcs, project_id, root_commit}`
- `snapshot_revision` — last applied seq
- `log_sha256` — hash of the log bytes at materialize time
- `acceptance_policy` — defaults for node acceptance

## Node

- `id` — `N-0001`
- `parent` — node id or null
- `title`
- `class` — `feature | redesign | refactor | discovery | inception | skeleton | parity | cutover | observation | human | milestone`
- `origin` — `operator | decomposition | discovery | consult | observation`
- `status` — `proposed | accepted | ready | in_progress | blocked | complete | deferred | rejected | split`
- `stage` — `discovery | challenge | design | implement | validate | verify | null`
- `revision` — optimistic concurrency token (integer)
- `lease` — `{run, acquired_at, heartbeat_at, expires_at}` or null
- `depends_on` — node ids
- `facets` — keys into `program/facet_map.yaml` (`ui` for ordinary UI quality; `design_experience` for material art-direction/divergence ceremony). `node.add`, `node.patch` and `task-check` call deterministic `resolve_facets()`: explicit UI terms (ui/ux/interface/screen, product/ui shell) and contextual surface objects (page, dashboard, checkout as the work object) may attach `ui`; `ui` plus material class/title (e.g. `redesign` with `ui`, a surface redesign/overhaul, material IA) may attach `design_experience`. Contextual tokens do not invent `ui` when they modify infrastructure/runtime/data concepts (page cache, deploy shell, dashboard aggregation). Generic programme classes or titles (backend redesign, data inception, major pipeline redesign, bare shell) do not invent `ui`.
- `target_artifact_class` — `ia_concept | interaction | high_fidelity`. **Per-node.** Required when `design_experience` is attached. Declared only as a structured acceptance-criterion line `target_artifact_class: <class>` (whole line; not free-text intent detection). A programme may sequence `ia_concept` → `interaction` → `high_fidelity` as three separate node completions. Missing target fails the quality gate the same way as a missing delivered class.
- `design_artifact_class` — delivered class on this node (`ia_concept | interaction | high_fidelity`). Must satisfy the node's target: `ia_concept < interaction < high_fidelity` (delivered rank ≥ target rank). An `ia_concept` delivery cannot complete a `high_fidelity` target. High-fidelity-only evidence kinds cannot `pass` on an `ia_concept` node.
- `risk` — `R0`–`R4`
- `touches_existing` — bool
- `acceptance` — `auto | operator`
- `acceptance_state` — `not_required | pending | accepted`
- `acceptance_criteria` — strings
- `baseline_ref` — baseline id or null
- `parity_source` — list of source capability names (parity class)
- `parity_matrix` — map capability → `port | replace | retire`
- `quality` — map dim → `{required, state, evidence, rationale}`
- `verification` — `{referent, rendered, behavioral, journeys?}`. `rendered` and `behavioral` are unchanged. When `select_journeys()` returns applicable journeys for a node, `journeys` is required: `{state, required_ids, covered_ids, evidence, rationale}` where `required_ids` is frozen in the `node.verification` event payload at verification time (current catalogue selection when the event is recorded; replay uses the persisted set, not today's `JOURNEYS.yaml`), `state` is `pending | pass | resolved | na`, every `required_ids` entry must appear in `covered_ids` for `pass`/`resolved`, `na` requires `rationale`, and a generic `rendered` pass alone does not satisfy the journey gate. Nodes with no applicable journeys carry no `journeys` ceremony. Evidence is simulated product evaluation, not real-user research. Record via `node.verification` with `kind: journeys`. `JOURNEYS.yaml` required fields are `id`, `name`, and a non-empty `steps` list. `success_criteria` is optional so a file valid under published v0.5.1 remains valid; when present it must be a non-empty list. Loaders must not rewrite host journey files to add it. Current templates still include it. Replay of a v0.5.1 skeleton `complete` that has rendered evidence but no journeys verification record must not fail; new completes still require the journeys gate (E-J3).
- `evidence` — evidence ids
- `blockers` — `{id, type, ref, opened}`
- `conservation_tags` — extra strings for noun accounting
- `fingerprint` — observation dedupe key
- `stage_note` — parked in-flight note
- `debug_iterations` — int
- `split_into` — node ids or null
- `deferred` / `rejected` — `{decision, note}` or null

## Terminal statuses

`complete`, `deferred`, `rejected`, `split`. Split requires `split_into`. Deletion does not exist.

Parent/root `complete` is **derived** in the snapshot (`effective_status`) and must not be asserted as an event on a non-leaf.

## Quality states

`pending | pass | resolved | na | blocked`

Completion of a leaf requires every `required` dimension in `{pass, resolved, na}` with rationale for `na`.

On `design_experience` nodes, `design_artifact_class` cannot be `na`. Class-skippable dimensions (`design_interaction_spec`, `design_state_coverage`, `design_identity_tokens`, `design_execution_decisions`) may be `na` on a lower class only with rationale containing `artifact_class=<delivered_class>`. `high_fidelity` cannot `na` identity tokens, state coverage, or interaction spec; `design_execution_decisions` must `pass` with structured `applicable | not_applicable` slots (`responsive_decision`, `visualisation_decision`, `consequential_action_decision`) — not dummy `na`. Evidence is process presence, not an aesthetic score. The `DESIGN_EXPERIENCE_RECORD.md` file remains optional and is not a second ledger.

## Decision

- `id` — `D-0001`
- `scope` — node id whose subtree the decision may affect
- `statement`
- `origin`
- `status` — `proposed | accepted | superseded`
- A scoped decision may mutate the scope node and its descendants only. Ancestor mutation and sibling close/remove require parent scope.

## Baseline

- `id` — `BLN-0001`
- `provenance` — `implementation-observation` (valid) or `design-direction` (invalid as baseline)
- `tree_hash`
- `latent_capabilities` — names that redesign must preserve, port, or retire-with-decision
- `preservation` — map old → new home or `{retire: decision_id}`

## Invariants (validator)

1. Log seq contiguous; snapshot `snapshot_revision` equals log head.
2. No delete. Every node ends terminal or still open.
3. Root/parent complete is derived: all descendants terminal and own gates met.
4. Anti-eclipse: decision/mutation scoped to N cannot alter ancestors of N or close/remove siblings of N.
5. Baseline gate: `redesign|refactor|parity`, or `feature` with `touches_existing` and risk ≥ R2, cannot leave `discovery` without a valid baseline_ref whose provenance is not `design-direction`.
6. Quality gate on leaf complete.
7. Live foreign lease blocks mutation; expiry is permission to reclaim, not a stale-revision override.
8. Every node mutation carries `expected_revision` matching the node's current revision.
9. Direct file-tool writes to `.eif/program/**` are denied by the guard; `program.py` is the canonical writer. Child-process immutability is **not** claimed where process containment is UNAVAILABLE. `verify` detects snapshot/log divergence.
10. Observation nodes may only propose; they must not mutate other nodes.

## Task mode

Absence of `.eif/program/` is task mode. `program.py task-check` applies `resolve_facets()` then the quality engine without a ledger. `program.py journeys` validates `.eif/JOURNEYS.yaml` and selects journeys by node class/facet/criticality for rendered evaluation hints. Removing `.eif/program/` restores v0.4-compatible task semantics. Full framework rollback is tag `v0.4.0`.

## Version surfaces

These identifiers are not the same thing. Do not collapse them.

| Surface | Current value | Meaning |
|---|---|---|
| `specialists.registry.yaml` `framework_version` + `schema_version` | `0.3.0-draft` / `0.3` | Specialist catalog **schema contract**. `validate.py` requires this exact `framework_version`. Changing it is a catalog-schema migration, not a product tag. Programme Release does not change that schema. |
| `tools/compile_policy.py` emitted `framework_version` | `0.4.0-draft` (`schema_version` 3) | Compiled **runtime policy envelope** matching freeze v0.4 L3. Programme Release does not change that compile schema. |
| `VERSION` + README Status | `0.7.0-draft` | **Product/bundle** version (`generate_bundle.py`). Design Intelligence artifact-class minor on Design & Experience Intelligence `0.6.0-draft` / git tag `v0.6.0` and patch `0.6.1-draft` / `v0.6.1`. Programme Release remains `0.5.0-draft` / `v0.5.0`; published install/upgrade patch remains `v0.5.1`. Tag `v0.4.0` remains the v0.4 freeze / rollback. Do not retag or rewrite `v0.6.1`, `v0.6.0`, `v0.5.0`, or `v0.5.1`. Proposed minor tag: `v0.7.0`. |
| `install_project.py` "v0.3 install" | L0/L1 bootstrap | **Install-safety protocol** generation (safe local audit/recommend). Not the product version and not the catalog schema. Fresh `install` vs in-place `upgrade`/`recover` are distinct commands; upgrade does not reset accepted policy. |

Historical `EIF_REVIEW_HANDOFF_BUNDLE.md` still embeds `0.3.2-draft` as a frozen review snapshot. Do not treat it as live product version.

