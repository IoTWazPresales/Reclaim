# Volume 14 — Evidence, Decisions and Confidence Protocol

## 14.1 Why this exists

AI systems are most dangerous when fluent uncertainty is mistaken for knowledge. EIF therefore makes epistemic state part of the artifact.

---

## 14.2 Evidence hierarchy

Use the strongest available source for the claim.

### E0 — Direct executable observation
Examples:
- test result;
- runtime output;
- database constraint/query;
- source code path;
- reproducible benchmark.

### E1 — Verified canonical project source
Examples:
- accepted ADR or decision (evidence of the decision);
- operator-accepted canonical requirement (evidence of intended requirement);
- approved API contract;
- authoritative schema;
- verified project manifest field.

**Residence is not qualification.** Text becomes E1 because its authority/provenance is established for the claim, not because it is stored in a canonical EIF file.

### E2 — Trusted primary external source
Examples:
- official standard;
- vendor documentation;
- original research;
- government/regulatory text.

### E3 — Credible secondary source
Useful for synthesis and comparison but weaker than primary evidence.

### E4 — Stakeholder statement
Important, but may describe intended rather than actual behavior.

### E5 — Model inference
Useful for hypothesis formation only until supported.

Evidence strength is claim-dependent. Source code may describe current implementation but not intended business behavior. A product requirement may describe intent but not runtime truth.

Documentation, README, tickets and unconfirmed ADRs are not E0 for current behavior. Using them as the system map is an intelligence-bar failure (Volume 25), not an evidence shortcut.

---

## 14.3 Evidence record

```yaml
id:
claim:
class: FACT|INFERENCE|ASSUMPTION|HYPOTHESIS|PROPOSAL|UNKNOWN|CONSTRAINT|DECISION
source:
resolver_or_reproduction:
observed_at:
verified_at:
verified_by:
scope:
strength: E0|E1|E2|E3|E4|E5
freshness:
coverage:
limitations:
confidence:
falsification_condition:
```

---

## 14.3A Persistence and evidence lineage

Writing a statement into persistent context never strengthens it.

- Model-generated conclusions remain `INFERENCE` unless new evidence changes their class.
- Unverified machine-drafted context is marked `UNVERIFIED`.
- Derived claims cite contributing evidence; synthesis does not erase lineage.
- Operator acceptance may make something a `DECISION` or `CONSTRAINT`, but does not transform an unobserved external-world claim into a verified FACT.
- Promotion to stronger evidence requires a verification event, not repeated reuse.

For material claims, use the compact provenance format defined in Volume 2 §2.4.

### Evidence-pointer validity

A repository FACT backed by a path/symbol/test/command must have a resolver/reproduction method where technically feasible. If GOV-008 cannot resolve the pointer, dependent conclusions are invalidated until re-established.

Ephemeral/non-executable evidence such as stakeholder statements or changing web pages must preserve source identity, exact claim, observation date and limitations instead of pretending reproducibility.

---

## 14.4 External freshness

For claims that can change:
- record observation date;
- record product/version/tier;
- record geography if relevant;
- do not reuse old comparisons as “current.”

Examples:
- model capabilities;
- vendor pricing;
- API limits;
- competitors;
- legal/regulatory requirements;
- package versions;
- cloud service behavior.

If current verification is unavailable:
> “Unverified current-state assumption — validate before decision.”

---

## 14.5 Decision protocol

Material decisions should answer:

1. What decision are we making?
2. Why now?
3. What evidence constrains it?
4. What alternatives were considered?
5. What are the trade-offs?
6. What is the blast radius?
7. How reversible is it?
8. What could invalidate it?
9. How will we verify?
10. When should it be reviewed?

### Decision status
- PROPOSED
- ACCEPTED
- SUPERSEDED
- REJECTED
- EXPERIMENTAL
- DEFERRED

---

## 14.6 ADR trigger guide

Create/record an ADR when changing:
- system boundary;
- major technology;
- canonical data ownership;
- public contract;
- authentication/authorization model;
- tenancy;
- event semantics;
- major persistence pattern;
- major UI/navigation mental model;
- AI orchestration architecture;
- material build-vs-buy choice.

Do not create an ADR for every function or CSS choice.

---

## 14.7 Assumption management

Every material assumption needs one of:
- accepted risk;
- validation task;
- expiry condition.

Assumptions should not become permanent invisible architecture.

Illustrative example:

```md
A-017
Assumption: The upstream source changes no more frequently than every 15 minutes.
Impact: Cache and refresh design.
Validate: Production event-rate query.
Owner: Data specialist.
Status: OPEN.
```

---

## 14.8 Hypothesis testing

A good hypothesis is falsifiable.

Bad:
> “Users will love AI insights.”

Good:
> “For support agents preparing to handle a case, showing three evidence-linked recent changes in the overview will reduce median preparation time without increasing false-positive dismissal rate.”

Define:
- population;
- intervention;
- expected effect;
- metric;
- threshold;
- failure signal.

---

## 14.9 Market evidence discipline

Market comparison output must distinguish:

**Observed**
> Product X exposes a timeline view on Tier Y, observed on DATE.

**Inference**
> This likely reduces the cost of scanning recent changes.

**Proposal**
> Evaluate a condensed timeline for the relevant overview workflow.

Never merge these into:
> “Best practice is a timeline.”

---

## 14.9A Negative evidence and search coverage

“No evidence found” describes a search, not a system fact.

Every material negative claim states:
- search method;
- repositories/sources covered;
- dynamic/reflection/cross-repo limitations;
- date/baseline.

Examples:
- acceptable: “No static callers found by symbol/reference search in repositories A and B; runtime reflection and external consumers were not covered.”
- unacceptable: “This function has no callers, therefore it is dead.”

Absence alone cannot justify deletion, deprecation, a security claim, or a market-gap claim.

---

## 14.10 Scientific posture

“Science-based” means:
- testable claims;
- reproducible observation;
- quantified evidence when appropriate;
- explicit uncertainty;
- updating beliefs when evidence changes.

It does **not** mean:
- only peer-reviewed ideas may be used;
- qualitative evidence is invalid;
- novelty is forbidden;
- false precision is acceptable.

---

## 14.11 Decision scoring

Scoring matrices may support—not replace—judgment.

Suggested dimensions for major options:
- user value;
- business value;
- correctness;
- delivery risk;
- security/privacy;
- maintainability;
- performance;
- cost;
- reversibility;
- strategic fit.

Weights must be explicit. Avoid decimal precision unsupported by evidence.

