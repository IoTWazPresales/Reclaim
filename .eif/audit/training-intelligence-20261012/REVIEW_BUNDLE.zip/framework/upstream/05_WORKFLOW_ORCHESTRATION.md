# Volume 5 — Workflow and Orchestration Engine

## 5.1 Lifecycle

### Audit-only route

When the requested outcome is "audit/review/assess the project" rather than "change the project", GOV-001 routes **Audit Mode** at L0/L1 implementation authority with implementation change scope `NONE`.

This is a Volume 25 critique run, not a GOV-003-only documentation harvest. The orchestrator must invoke at least:

- GOV-003 for evidence baseline and bundle ownership;
- PB-002 (and PB-001 when product direction is in scope);
- AE-002 at the relevant architecture altitude;
- CR-007, plus CR-002 when accretion/complexity is visible;
- UX-001, UX-003 and UX-005 when a renderable UI exists (UX-002 when flows/states are material).

The run may use a broad observation scope. Isolated `.eif/` audit/proposal artifacts may be written when artifact write scope allows. It produces AS-IS evidence, independent SHOULD-BE critique, visual inspection where applicable, ranked opportunities and proposals. Any remediation requires a separately accepted work item and normal authority gates. `NONE` does not authorize timid or docs-only output.

A project/module audit is not R0 merely because it cannot implement.


EIF uses stage gates but not a rigid waterfall. Ceremony scales with risk.

### Stage A — Bootstrap and run envelope
Inputs:
- task/request;
- project identity/boundary;
- authority/autonomy policy;
- risk classification;
- runtime enforcement capability.

Outputs:
- scoped `WORK_ITEM.md`;
- discovery depth;
- run/loop budgets;
- intended canonical-state writers;
- adjacent-scope allowance if any.

Gate:
- project identity/fingerprint valid;
- required security guards available for proposed authority.

### Stage B — Discovery
Output:
- compact R0/R1 confirmation, targeted R2 discovery, or full R3/R4 bundle.

Gate:
- sufficient evidence/coverage for the planned action.

### Stage C — Problem framing
Specialists:
- Product Manager;
- Business Analyst;
- Domain Analyst as needed.

Output:
- governing business rule;
- acceptance criteria;
- success measures;
- non-goals.

Gate:
- implementation is solving the intended outcome, not merely the requested solution.

### Stage D — Option design
Invoke the minimum relevant architecture/data/UX/security/algorithm/product specialists.

Output:
- materially distinct alternatives where they genuinely exist;
- trade-offs;
- recommendation;
- ADR candidate when required.

Gate:
- chosen approach defensible for risk/reversibility.

### Stage E — Delivery plan
Output:
- work packages;
- dependencies;
- allowed paths/action classes;
- test strategy;
- migration/rollback;
- observability;
- verification route;
- state-write ownership.

Gate:
- work is implementable, bounded and verifiable.

### Stage F — Implementation
Implementers work inside the granted autonomy envelope.

Gate:
- local checks pass;
- no protected/action-policy violation;
- budgets not exhausted.

### Stage G — Independent verification/review
GOV-008 verifies evidence referents and execution claims. Add relevant challenge/domain review according to risk.

Gate:
- required evidence pointers resolve;
- blocking findings resolved or escalated.

### Stage H — Integration / release readiness
Output:
- integrated verification;
- migration readiness;
- operational notes;
- rollback proof;
- release readiness.

L5 actions require `ENVIRONMENT_POLICY.md`; readiness is not authority.

### Stage I — Closeout
Assigned state writers update canonical files with provenance and append-only discipline.

### Stage J — Opportunity loop
Record improvements separately. Implementation is off by default unless explicitly enabled in `AUTONOMY_POLICY.md`.

### Programme loop (when `.eif/program/` exists)

GOV-001 checks out one frontier node (lease + heartbeat + expected revision) and advances its stage machine: discovery → challenge → design → implement → validate → verify. Park with a stage note and release the lease at wrap-up. The next session runs `python tools/program.py status` and continues from durable state; do not ferry scope in chat.

A node completes only through the validator (quality gate, verification states, acceptance policy). Root complete is derived. CONSULT outcomes attach at their scope; parent/mandate change becomes a Decision Queue item, never a side effect of a child consult.

Task mode uses this same quality/completion engine without a ledger (`python tools/program.py task-check`).

## 5.2 Routing matrix

### Bug
Required:
- Discovery/Diagnosis
- relevant implementation specialist
- Test/QA
Optional:
- Security if trust boundary
- Data if integrity
- UX if user-visible

### New feature
Required:
- Discovery
- Product
- Architecture appropriate to scope
- implementation
- QA
Optional:
- UX, Data, Security, Market

### Refactor
Required:
- Discovery
- Maintainability/Architecture
- regression strategy
- implementation reviewer

No refactor may be justified solely by “cleaner.”

### Schema change
Required:
- Discovery
- Data Architect/DB Specialist
- owning backend specialist
- QA
- rollback/migration review

### Auth/security
Required:
- Discovery
- Security
- relevant architect/engineer
- QA
- independent Security Skeptic

### UI redesign
Required:
- Discovery
- Product
- UX
- UI (including rendered inspection when a UI exists)
- Accessibility
- frontend
- QA

### Project/module audit
Required:
- GOV-003 evidence baseline
- Product critique
- Architecture critique
- Product red team
- UX/visual/a11y when a renderable UI exists

Output is L1 proposals only. Implementation is a later envelope.

### Performance
Required:
- measured baseline
- Performance Specialist
- owning engineer
- verification benchmark

No speculative performance optimization.

---

## 5.3 Orchestrator planning format

```md
# Work Plan

Project:
Project fingerprint status:
Objective:
Observation scope:
Change scope:
Non-scope:
Authority:
Risk:
Autonomy policy:
Discovery tier/status:
Runtime enforcement: ENFORCED | ADVISORY | UNAVAILABLE
Run budget:
Adjacent-scope allowance:

## Canonical state writers
- CURRENT:
- DECISIONS:
- ...

## Work packages
1. ...
   Specialist:
   Inputs:
   Allowed paths:
   Allowed action classes:
   Intended state writes:
   Output:
   Dependency:
   Budget:
   Gate:
   Stop condition:

## Review / verification matrix
- ...

## Escalation conditions
- ...

## Definition of done
- ...
```

A work plan that omits authority, action boundaries or verification is incomplete for L3+ work.

## 5.4 Parallelization and state concurrency

Parallelize only independent investigations or implementations.

Good:
- security review and UX review of a stable proposal;
- database analysis and frontend analysis when interface is fixed;
- independent market comparison and repository discovery.

Bad:
- two agents editing the same core file without coordination;
- backend and frontend implementing an API before contract agreement;
- multiple agents rewriting persistent context.

Rules:
1. GOV-001 assigns a single writer for each canonical state file per run.
2. Parallel packages declare intended state writes before dispatch.
3. Overlapping declarations are a planning error and must be resolved first.
4. `DECISIONS`, `LESSONS`, `OPPORTUNITY_REGISTER`, and `RISK_REGISTER` are append-only.
5. `CURRENT.md` never uses last-writer-wins; specialists return proposed patches to its assigned writer.

## 5.5 Disagreement protocol

When specialists disagree, record:

- decision question;
- option A;
- option B;
- evidence for each;
- assumptions;
- impact;
- reversibility;
- experiment that could resolve it.

The orchestrator may decide if:
- within authority;
- evidence clearly favors one;
- decision is reversible.

Otherwise escalate.

---

## 5.6 Autonomous debugging loop

Default maximum: **5 iterations**, unless the work plan explicitly sets another bounded value.

1. Reproduce.
2. Capture observed failure.
3. State expected behavior and evidence.
4. Generate ranked hypotheses.
5. Select the cheapest discriminating test.
6. Run the test.
7. Update hypotheses.
8. Fix root cause only when evidence supports it.
9. Add/adjust regression verification.
10. Run affected suite.
11. Inspect collateral behavior.
12. Update handoff/state.

Stop early when:
- two consecutive iterations yield no new discriminating evidence;
- the hypothesis and test are unchanged;
- the supposed discriminator is flaky under identical input;
- required scope/authority expands;
- budget is exhausted.

A flaky test becomes its own finding/work item. Do not “fix” product code to satisfy nondeterministic noise.

## 5.7 Autonomous improvement loop

After the accepted task is complete:

1. inspect local opportunities;
2. record them in `OPPORTUNITY_REGISTER.md`;
3. rank by impact, risk-of-inaction, then effort (Volume 25);
4. implement **zero** opportunity items by default.

Opportunity implementation is allowed only when `AUTONOMY_POLICY.md` grants an improvement budget and the item:
- fits that explicit budget/type;
- remains within scope/adjacent-scope policy;
- is below the granted risk ceiling;
- has verification;
- does not delay the accepted outcome.

“While we are here” is not authorization.

