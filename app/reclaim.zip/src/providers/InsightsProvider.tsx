// C:\Reclaim\app\src\providers\InsightsProvider.tsx

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type PropsWithChildren,
} from 'react';
import { useQuery } from '@tanstack/react-query';

import rawRules from '@/data/insights.json';
import {
  createInsightEngine,
  type InsightMatch,
  type InsightContext,
  type InsightRule,
  type InsightFeedbackIndex,
  type InsightFeedbackLatest,
} from '@/lib/insights/InsightEngine';
import { fetchInsightContext, type InsightContextSourceData } from '@/lib/insights/contextBuilder';
import { logger } from '@/lib/logger';
import { useAuth } from '@/providers/AuthProvider';
import { getUserSettings } from '@/lib/userSettings';

type InsightStatus = 'idle' | 'loading' | 'ready' | 'error';

type InsightValue = {
  insight: InsightMatch | null;
  insights: InsightMatch[];
  status: InsightStatus;
  lastUpdatedAt?: string;
  lastContext?: InsightContext;
  lastSource?: InsightContextSourceData;
  enabled: boolean;
  setEnabled: (value: boolean) => void;
  refresh: (reason?: string) => Promise<InsightMatch | null>;
  error?: string;
};

const ScientificInsightContext = createContext<InsightValue | undefined>(undefined);

const rules = rawRules as InsightRule[];

// Policy values
const NOT_RELEVANT_MS = 24 * 60 * 60 * 1000;
const NOT_HELPFUL_COOLDOWN_DAYS = 7;

// Neutral cooldown insight
function makeCooldownInsight(): InsightMatch {
  return {
    id: 'cooldown-not-relevant',
    sourceTag: 'cooldown',
    icon: 'clock-outline',
    message: 'No new insight right now.',
    action: 'Log a quick check-in or refresh later.',
    why: 'You marked the current suggestion as “not relevant now”, so I’m holding off for a bit.',
    matchedConditions: [],
  } as any;
}

function normalizeId(id: any): string {
  return String(id ?? '').trim();
}

/**
 * Primary feedback index — built ONLY from contextBuilder result
 */
function buildFeedbackIndex(
  latestById: Record<string, any> | null | undefined,
): InsightFeedbackIndex | null {
  if (!latestById) return null;

  const entries = Object.entries(latestById);
  if (!entries.length) return null;

  const newest = entries
    .map(([, v]) => String((v as any)?.created_at ?? ''))
    .sort()
    .slice(-1)[0];

  return {
    fingerprint: `feedback:${entries.length}:${newest}`,
    getLatest: (insightId: string): InsightFeedbackLatest | null => {
      const key = normalizeId(insightId);
      const row = (latestById as any)[key];
      if (!row) return null;
      return {
        created_at: String(row.created_at ?? ''),
        helpful: !!row.helpful,
        reason: row.reason ?? null,
      };
    },
  };
}

export function InsightsProvider({ children }: PropsWithChildren) {
  const { session, loading: authLoading } = useAuth();

  const [enabled, setEnabled] = useState(true);
  const [insight, setInsight] = useState<InsightMatch | null>(null);
  const [insights, setInsights] = useState<InsightMatch[]>([]);
  const [status, setStatus] = useState<InsightStatus>('idle');
  const [error, setError] = useState<string | undefined>();

  const [lastUpdatedAt, setLastUpdatedAt] = useState<string>();
  const [lastContext, setLastContext] = useState<InsightContext>();
  const [lastSource, setLastSource] = useState<InsightContextSourceData>();

  const inflight = useRef<Promise<InsightMatch | null> | null>(null);

  const { data: userSettings } = useQuery({
    queryKey: ['user:settings'],
    queryFn: getUserSettings,
  });

  const refresh = useCallback(
    async (reason?: string): Promise<InsightMatch | null> => {
      if (!enabled || !session) {
        setInsight(null);
        setInsights([]);
        setStatus(enabled ? 'ready' : 'idle');
        return null;
      }

      if (inflight.current) return inflight.current;

      setStatus('loading');
      setError(undefined);

      const run = (async () => {
        try {
          const { context, source } = await fetchInsightContext();

          const feedbackIndex = buildFeedbackIndex(source.insightFeedbackLatestById);

          // 🔑 IMPORTANT: rebuild engine when feedback fingerprint changes
          const engine = createInsightEngine(rules);

          const evaluated = feedbackIndex
            ? engine.evaluateAll(context, {
                now: new Date(),
                feedback: {
                  index: feedbackIndex,
                  cooldownDays: NOT_HELPFUL_COOLDOWN_DAYS,
                  notRelevantMs: NOT_RELEVANT_MS,
                },
              })
            : engine.evaluateAll(context);

          let chosen: InsightMatch | null = evaluated[0] ?? null;
          let finalList = evaluated;

          if (feedbackIndex && evaluated.length === 0) {
            const raw = engine.evaluateAll(context);
            if (raw.length > 0) {
              chosen = makeCooldownInsight();
              finalList = [chosen];
            }
          }

          setInsight(chosen);
          setInsights(finalList);
          setLastContext(context);
          setLastSource(source);
          setLastUpdatedAt(new Date().toISOString());
          setStatus('ready');

          logger.debug('Insight refreshed', {
            reason,
            chosenId: chosen?.id ?? null,
            feedbackFingerprint: feedbackIndex?.fingerprint ?? null,
          });

          return chosen;
        } catch (err: any) {
          logger.warn('Insight computation failed', err);
          setInsight(null);
          setInsights([]);
          setStatus('error');
          setError(err?.message ?? 'Unable to compute insight');
          return null;
        } finally {
          inflight.current = null;
        }
      })();

      inflight.current = run;
      return run;
    },
    [enabled, session],
  );

  const value = useMemo<InsightValue>(
    () => ({
      insight,
      insights,
      status,
      lastUpdatedAt,
      lastContext,
      lastSource,
      enabled,
      setEnabled,
      refresh,
      error,
    }),
    [enabled, error, insight, insights, lastContext, lastSource, lastUpdatedAt, refresh, status],
  );

  // Sync enabled from settings
  useEffect(() => {
    if (userSettings?.scientificInsightsEnabled !== undefined) {
      setEnabled(userSettings.scientificInsightsEnabled);
    }
  }, [userSettings?.scientificInsightsEnabled]);

  // Clear when disabled
  useEffect(() => {
    if (!enabled) {
      setInsight(null);
      setInsights([]);
      setStatus('ready');
    }
  }, [enabled]);

  // Initial refresh
  useEffect(() => {
    if (authLoading || !session || !enabled) return;
    refresh('session-ready').catch(() => {});
  }, [authLoading, enabled, refresh, session]);

  return <ScientificInsightContext.Provider value={value}>{children}</ScientificInsightContext.Provider>;
}

export function useScientificInsights(): InsightValue {
  const ctx = useContext(ScientificInsightContext);
  if (!ctx) throw new Error('useScientificInsights must be used within InsightsProvider');
  return ctx;
}
