// Adjust if you already have these — just extend them.
export type RootStackParamList = {
  Tabs: undefined;
  // ...other modals / stacks
};

export type TabParamList = {
  Home: undefined;     // example
  Meds: undefined;     // example
  Mood: undefined;     // NEW
  // ...other tabs
};
