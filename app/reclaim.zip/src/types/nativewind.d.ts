/// <reference types="nativewind/types" />
