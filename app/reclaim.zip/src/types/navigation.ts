export type RootStackParamList = {
  Dashboard: undefined;
  FocusArena: undefined;
  Mindfulness: undefined;
  Meds: undefined;
  Settings: undefined;
};
