declare module 'react-native-paper' {
  const PaperModule: any;
  export default PaperModule;
  export const ActivityIndicator: any;
  export const Button: any;
  export const Card: any;
  export const Chip: any;
  export const Divider: any;
  export const FAB: any;
  export const HelperText: any;
  export const IconButton: any;
  export const List: any;
  export const Portal: any;
  export const Snackbar: any;
  export const Text: any;
  export const useTheme: any;
  export const PaperProvider: any;
  export const TextInput: any;
  export const MD3LightTheme: any;
  export const Switch: any;
}

