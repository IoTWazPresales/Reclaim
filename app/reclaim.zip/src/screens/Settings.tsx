import React from 'react';
import SettingsScreen from '@/screens/SettingsScreen';

export default function Settings() {
  return <SettingsScreen />;
}
