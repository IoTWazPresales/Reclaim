/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{ts,tsx}", "./App.tsx"],
  theme: { extend: {} },
  plugins: []
}
